function renderTable(data, title, containerId) {
  const container = document.getElementById(containerId);
  const section = document.createElement("section");
  section.innerHTML = `<h2>${title}</h2>`;

  const contentBox = document.createElement("div");
  contentBox.classList.add("content-box");

  data.forEach(item => {
    const div = document.createElement("div");
    div.classList.add("item");
    div.innerHTML = `<span>${item.hanzi}</span><span>${item.khmer}</span>`;
    contentBox.appendChild(div);
  });

  section.appendChild(contentBox);
  container.appendChild(section);
}

const pronunciationExplanation = {
  title: "សំឡេង 'ü' ក្នុងភាសាចិន (Pinyin)",
  explanation: `សំឡេង 'ü' ក្នុងភាសាចិន (Pinyin)",
  explanation: កុំគិតថា "ü" គឺសំឡេងដូចជា "u" ឬសំឡេងដែលមានច្រិតៗគ្នា។ 
ពីព្រោះសញ្ញាស្ពៃៗ (ü) មានភាពខុសគ្នាទៅកាន់សំឡេងណាស់!

ដើម្បីបញ្ចេញសំឡេង "ü" របស់ភាសាចិន សូមចាប់ផ្តើមពីការបញ្ចេញសំឡេង "yi" 
(ឬសំឡេង "ee" ក្នុងភាសាអង់គ្លេស) បន្ទាប់មកបត់មាត់របស់អ្នកឱ្យបង្វិល (rounded)។ 
នោះគឺជាវិធីងាយៗ។ ប៉ុន្តែភាសាគ្រោងនៅតាមទីតាំងនៅក្នុងច្រមុះត្រូវតែតឹងប្រសិនបើអ្នកកំពុងចេញសំឡេង 
"yi" ខណៈដែលមាត់ត្រូវតែបង្វិលតិចតួច។ ប្រសិនបើអ្នកកំពុងមានបញ្ហាក្នុងការបញ្ចេញសំឡេងនេះ 
គឺវាអាចជាហេតុផលពីការចេញសំឡេង "oo" (សំឡេងអង់គ្លេស) ដែលបន្ទាន់លើភាសាខ្មែរប៉ុន្តែត្រូវការពន្លូតទៀងតែងសំឡេង "ee"។

🔹 yu
"yu" គឺជាសំឡេង "ü" ដែល "y" ត្រូវបានបន្ថែម ដើម្បីមិនបញ្ចូលសញ្ញាដុត (ü)។ សំឡេងដូចគ្នា: "nü", "lü"។ 

🔹 yue
"yue" = "ü" + "eh"។ សំឡេងដូចជា "nüe", "lüe"។ មិនដាក់សញ្ញាដុតក្នុងករណីនេះ។

🔹 yuan
"yuan" = "ü" + "en"។ ដូចជា "yan" ប៉ុន្តែជាមួយ "ü"។ 

🔹 yun
"yun" = "ü" + "n"។ បង្ហាញថា "yu" + "n" (ដូចជា "yin")។ 

📝 ពេលណាដែលត្រូវដាក់សញ្ញាដុត?
សញ្ញាដុតត្រូវបានដាក់នៅពេលដែលអក្សរចាប់ផ្តើមអាចភ្ជាប់ជាមួយទាំង -u និង -ü ដូចជា "nu/nü", "lu/lü"។ ដើម្បីជៀសវាងការច្រឡំ ត្រូវដាក់សញ្ញាដុតលើ "ü" នៅពេលចាំបាច់។`
};

function displayPronunciationExplanation() {
  const titleEl = document.getElementById("pronunciationTitle");
  const textEl = document.getElementById("pronunciationText");

  titleEl.textContent = pronunciationExplanation.title;
  textEl.textContent = pronunciationExplanation.explanation;
}

// Data Arrays
const initials = [
  { hanzi: "b→", khmer: "ប៉" }, { hanzi: "p", khmer: "ផ" },
  { hanzi: "m", khmer: "ម៉" }, { hanzi: "f", khmer: "ហ្វ" },
  { hanzi: "d", khmer: "តឺ" }, { hanzi: "t", khmer: "ថឺ" },
  { hanzi: "n", khmer: "ណឺ" }, { hanzi: "l", khmer: "ឡឺ" },
  { hanzi: "g", khmer: "កឺ" }, { hanzi: "k", khmer: "ខឺ" },
  { hanzi: "h", khmer: "ហឺ" }, { hanzi: "j", khmer: "ជី" },
  { hanzi: "q", khmer: "ឈី" }, { hanzi: "x", khmer: "ស៊ី" },
  { hanzi: "zh", khmer: "ជឺ" }, { hanzi: "ch", khmer: "ឈឺ" },
  { hanzi: "sh", khmer: "ហ្សឺ" }, { hanzi: "r", khmer: "យឺ/រឺ" },
  { hanzi: "z", khmer: "ជឺ" }, { hanzi: "c", khmer: "ឈឺ" },
  { hanzi: "s", khmer: "សឺ" }, { hanzi: "y", khmer: "អ៊ី" },
  { hanzi: "w", khmer: "អ៊ូ" }
];

const finals = [
  { hanzi: "a→", khmer: "អា" }, { hanzi: "o", khmer: "អ" },
  { hanzi: "e", khmer: "អឺ" }, { hanzi: "i", khmer: "អ៊ី" },
  { hanzi: "u", khmer: "អ៊ូ" }, { hanzi: "ü", khmer: "អ៊ី៎ (មាត់ស្រួច)" },
  { hanzi: "ai", khmer: "អាយ" }, { hanzi: "ei", khmer: "អី" },
  { hanzi: "ui", khmer: "អួយ" }, { hanzi: "ao", khmer: "អៅ" },
  { hanzi: "ou", khmer: "អូវ" }, { hanzi: "iu", khmer: "អៀវ" },
  { hanzi: "ie", khmer: "អៀ" }, { hanzi: "üe", khmer: "អៀ (មាត់ស្រួច)" },
  { hanzi: "er", khmer: "អ៊ើ" }, { hanzi: "an", khmer: "អាន" },
  { hanzi: "en", khmer: "អិន" }, { hanzi: "in", khmer: "អ៊ិន" },
  { hanzi: "un", khmer: "អ៊ួន" }, { hanzi: "ün", khmer: "អ៊ីន" },
  { hanzi: "ang", khmer: "អាង" }, { hanzi: "eng", khmer: "អ៊ឹង" },
  { hanzi: "ing", khmer: "អ៊ីង" }, { hanzi: "ong", khmer: "អុង" }
];

const zhengtiyin = [
  { hanzi: "zhi", khmer: "ជឺ" }, { hanzi: "chi", khmer: "ឈឺ" },
  { hanzi: "shi", khmer: "ហ្សឺ" }, { hanzi: "ri", khmer: "យឺ/រឺ" },
  { hanzi: "zi", khmer: "ជឺ" }, { hanzi: "ci", khmer: "ឈឺ" },
  { hanzi: "si", khmer: "សឺ" }, { hanzi: "yi", khmer: "អ៊ី" },
  { hanzi: "wu", khmer: "អ៊ូ" }, { hanzi: "yu", khmer: "អ៊ី៎ (មាត់ស្រួច)" },
  { hanzi: "ye", khmer: "យៀ" }, { hanzi: "yue", khmer: "យៀ (មាត់ស្រួច)" },
  { hanzi: "yuan", khmer: "យៀន (មាត់ស្រួច)" }, { hanzi: "yin", khmer: "អីន" },
  { hanzi: "yun", khmer: "អ៊ី៎ន (មាត់ស្រួច)" }, { hanzi: "ying", khmer: "អីង" }
];

const words = [
  { hanzi: "我", khmer: "ខ្ញុំ" },
  { hanzi: "你", khmer: "អ្នក" },
  { hanzi: "他", khmer: "គាត់ (ប្រុស)" },
  { hanzi: "她", khmer: "គាត់ (ស្រី)" },
  { hanzi: "我们", khmer: "ពួកយើង" },
  { hanzi: "你们", khmer: "ពួកអ្នក" },
  { hanzi: "他们", khmer: "ពួកគាត់(មនុស្សប្រុស)" },
  { hanzi: "她们", khmer: "ពួកគាត់(មនុស្សស្រី)" },
  { hanzi: "它们", khmer: "ពួកវា(វត្ថុឬក៍សត្វ)" }
];
const numbers = [
  { "hanzi": "零", "pinyin": "líng", "khmer": "០" },
  { hanzi: "一", pinyin: "yī", khmer: "១" },
  { hanzi: "二", pinyin: "èr", khmer: "២" },
  { hanzi: "三", pinyin: "sān", khmer: "៣" },
  { hanzi: "四", pinyin: "sì", khmer: "៤" },
  { hanzi: "五", pinyin: "wǔ", khmer: "៥" },
  { hanzi: "六", pinyin: "liù", khmer: "៦" },
  { hanzi: "七", pinyin: "qī", khmer: "៧" },
  { hanzi: "八", pinyin: "bā", khmer: "៨" },
  { hanzi: "九", pinyin: "jiǔ", khmer: "៩" },
  { hanzi: "十", pinyin: "shí", khmer: "១០" },
  { hanzi: "十一", pinyin: "shí yī", khmer: "១១" },
  { hanzi: "十二", pinyin: "shí èr", khmer: "១២" },
  { hanzi: "十三", pinyin: "shí sān", khmer: "១៣" },
  { hanzi: "十四", pinyin: "shí sì", khmer: "១៤" },
  { hanzi: "十五", pinyin: "shí wǔ", khmer: "១៥" },
  { hanzi: "十六", pinyin: "shí liù", khmer: "១៦" },
  { hanzi: "十七", pinyin: "shí qī", khmer: "១៧" },
  { hanzi: "十八", pinyin: "shí bā", khmer: "១៨" },
  { hanzi: "十九", pinyin: "shí jiǔ", khmer: "១៩" },
  { hanzi: "二十", pinyin: "èr shí", khmer: "២០" },
  { hanzi: "二十一", pinyin: "èr shí yī", khmer: "២១" },
  { hanzi: "三十", pinyin: "sān shí", khmer: "៣០" },
  { hanzi: "四十", pinyin: "sì shí", khmer: "៤០" },
  { hanzi: "五十", pinyin: "wǔ shí", khmer: "៥០" },
  { hanzi: "六十", pinyin: "liù shí", khmer: "៦០" },
  { hanzi: "七十", pinyin: "qī shí", khmer: "៧០" },
  { hanzi: "八十", pinyin: "bā shí", khmer: "៨០" },
  { hanzi: "九十", pinyin: "jiǔ shí", khmer: "៩០" },
  { hanzi: "一百", pinyin: "yī bǎi", khmer: "១០០" }
];

const daysOfWeek = [
  { hanzi: "星期一", pinyin: "xīngqī yī", khmer: "ថ្ងៃច័ន្ទ" },
  { hanzi: "星期二", pinyin: "xīngqī èr", khmer: "ថ្ងៃអង្គារ" },
  { hanzi: "星期三", pinyin: "xīngqī sān", khmer: "ថ្ងៃពុធ" },
  { hanzi: "星期四", pinyin: "xīngqī sì", khmer: "ថ្ងៃព្រហស្បតិ៍" },
  { hanzi: "星期五", pinyin: "xīngqī wǔ", khmer: "ថ្ងៃសុក្រ" },
  { hanzi: "星期六", pinyin: "xīngqī liù", khmer: "ថ្ងៃសៅរ៍" },
  { hanzi: "星期日", pinyin: "xīngqī rì", khmer: "ថ្ងៃអាទិត្យ" },
  { hanzi: "星期天", pinyin: "xīngqī tiān", khmer: "ថ្ងៃអាទិត្យ" }

];

const months = [
  { hanzi: "一月", pinyin: "yī yuè", khmer: "ខែមករា" },
  { hanzi: "二月", pinyin: "èr yuè", khmer: "ខែកុម្ភៈ" },
  { hanzi: "三月", pinyin: "sān yuè", khmer: "ខែមីនា" },
  { hanzi: "四月", pinyin: "sì yuè", khmer: "ខែមេសា" },
  { hanzi: "五月", pinyin: "wǔ yuè", khmer: "ខែឧសភា" },
  { hanzi: "六月", pinyin: "liù yuè", khmer: "ខែមិថុនា" },
  { hanzi: "七月", pinyin: "qī yuè", khmer: "ខែកក្កដា" },
  { hanzi: "八月", pinyin: "bā yuè", khmer: "ខែសីហា" },
  { hanzi: "九月", pinyin: "jiǔ yuè", khmer: "ខែកញ្ញា" },
  { hanzi: "十月", pinyin: "shí yuè", khmer: "ខែតុលា" },
  { hanzi: "十一月", pinyin: "shí yī yuè", khmer: "ខែវិច្ឆិកា" },
  { hanzi: "十二月", pinyin: "shí èr yuè", khmer: "ខែធ្នូ" }
];


const chineseWords = [
  { hanzi: "年", pinyin: "nián", khmer: "ឆ្នាំ" },
  { hanzi: "月", pinyin: "yuè", khmer: "ខែ" },
  { hanzi: "日", pinyin: "rì", khmer: "ថ្ងៃ" },
  { hanzi: "星期", pinyin: "xīngqī", khmer: "សប្តាហ៍" },
  { hanzi: "下个星期", pinyin: "xià ge xīngqī", khmer: "សប្តាហ៍ក្រោយ" },
  { hanzi: "上个星期", pinyin: "shàng ge xīngqī", khmer: "សប្តាហ៍មុន" },
  { hanzi: "一个月", pinyin: "yī ge yuè", khmer: "មួយខែ" },
  { hanzi: "周末", pinyin: "zhōumò", khmer: "ចុងសប្តាហ៍" },
  { hanzi: "号", pinyin: "hào", khmer: "លេខ" }
];


const pinyinTones = [
  { hanzi: "ā", pinyin: "ā", khmer: "អា (សម្លេងទី 1)" },
  { hanzi: "á", pinyin: "á", khmer: "អា (សម្លេងទី 2)" },
  { hanzi: "ǎ", pinyin: "ǎ", khmer: "អា (សម្លេងទី 3)" },
  { hanzi: "à", pinyin: "à", khmer: "អា (សម្លេងទី 4)" },

  { hanzi: "ō", pinyin: "ō", khmer: "អ (សម្លេងទី 1)" },
  { hanzi: "ó", pinyin: "ó", khmer: "អ (សម្លេងទី 2)" },
  { hanzi: "ǒ", pinyin: "ǒ", khmer: "អ (សម្លេងទី 3)" },
  { hanzi: "ò", pinyin: "ò", khmer: "អ (សម្លេងទី 4)" },

  { hanzi: "ē", pinyin: "ē", khmer: "អឺ (សម្លេងទី 1)" },
  { hanzi: "é", pinyin: "é", khmer: "អឺ (សម្លេងទី 2)" },
  { hanzi: "ě", pinyin: "ě", khmer: "អឺ (សម្លេងទី 3)" },
  { hanzi: "è", pinyin: "è", khmer: "អឺ (សម្លេងទី 4)" },

  { hanzi: "ī", pinyin: "ī", khmer: "អ៊ី (សម្លេងទី 1)" },
  { hanzi: "í", pinyin: "í", khmer: "អ៊ី (សម្លេងទី 2)" },
  { hanzi: "ǐ", pinyin: "ǐ", khmer: "អ៊ី (សម្លេងទី 3)" },
  { hanzi: "ì", pinyin: "ì", khmer: "អ៊ី (សម្លេងទី 4)" },

  { hanzi: "ū", pinyin: "ū", khmer: "អ៊ូ (សម្លេងទី 1)" },
  { hanzi: "ú", pinyin: "ú", khmer: "អ៊ូ (សម្លេងទី 2)" },
  { hanzi: "ǔ", pinyin: "ǔ", khmer: "អ៊ូ (សម្លេងទី 3)" },
  { hanzi: "ù", pinyin: "ù", khmer: "អ៊ូ (សម្លេងទី 4)" },

  { hanzi: "ǖ", pinyin: "ǖ", khmer: "អ៊ី៎ (សម្លេងទី 1)" },
  { hanzi: "ǘ", pinyin: "ǘ", khmer: "អ៊ី៎ (សម្លេងទី 2)" },
  { hanzi: "ǚ", pinyin: "ǚ", khmer: "អ៊ី៎ (សម្លេងទី 3)" },
  { hanzi: "ǜ", pinyin: "ǜ", khmer: "អ៊ី៎ (សម្លេងទី 4)" }
];


const chineseHours = [
  { hanzi: "一点", pinyin: "yī diǎn", khmer: "ម៉ោង១" },
  { hanzi: "两点", pinyin: "liǎng diǎn", khmer: "ម៉ោង២" },
  { hanzi: "三点", pinyin: "sān diǎn", khmer: "ម៉ោង៣" },
  { hanzi: "四点", pinyin: "sì diǎn", khmer: "ម៉ោង៤" },
  { hanzi: "五点", pinyin: "wǔ diǎn", khmer: "ម៉ោង៥" },
  { hanzi: "六点", pinyin: "liù diǎn", khmer: "ម៉ោង៦" },
  { hanzi: "七点", pinyin: "qī diǎn", khmer: "ម៉ោង៧" },
  { hanzi: "八点", pinyin: "bā diǎn", khmer: "ម៉ោង៨" },
  { hanzi: "九点", pinyin: "jiǔ diǎn", khmer: "ម៉ោង៩" },
  { hanzi: "十点", pinyin: "shí diǎn", khmer: "ម៉ោង១០" },
  { hanzi: "十一点", pinyin: "shí yī diǎn", khmer: "ម៉ោង១១" },
  { hanzi: "十二点", pinyin: "shí èr diǎn", khmer: "ម៉ោង១២" },
  { hanzi: "上午一点", pinyin: "shàngwǔ yī diǎn", khmer: "ម៉ោង១ ព្រឹក" },
  { hanzi: "上午七点半", pinyin: "shàngwǔ qī diǎn bàn", khmer:"ម៉ោង៧ពេញកន្លះ ព្រឹក" },
  { hanzi: "上午十点十五分", pinyin: "shàngwǔ shí diǎn shí wǔ fēn",khmer: "ម៉ោង១០នាទី <br>១៥ ព្រឹក"},
  { hanzi: "下午两点", pinyin: "xiàwǔ liǎng diǎn", khmer: "ម៉ោង២ ល្ងាច" },
  { hanzi: "下午三点三十分", pinyin: "xiàwǔ sān diǎn sān shí fēn",khmer:"ម៉ោង៣នាទី<br>៣០ល្ងាច"},
  { hanzi: "下午五点半", pinyin: "xiàwǔ wǔ diǎn bàn", khmer: "ម៉ោង៥កន្លះល្ងាច" },
  { hanzi: "中午十二点", pinyin: "zhōngwǔ shí èr diǎn", khmer: "ម៉ោង១២ថ្ងៃត្រង់" }
];

const timePeriods = [
  { hanzi: "早上", pinyin: "zǎoshang", khmer: "ព្រឹកដើម"},
  { hanzi: "上午", pinyin: "shàngwǔ", khmer: "ព្រឹក"},
  { hanzi: "中午", pinyin: "zhōngwǔ", khmer: "ថ្ងៃត្រង់"},
  { hanzi: "下午", pinyin: "xiàwǔ", khmer: "ល្ងាច"},
  { hanzi: "傍晚", pinyin: "bàngwǎn", khmer: "ល្ងាចចុង"},
  { hanzi: "晚上", pinyin: "wǎnshang", khmer: "យប់"},
  { hanzi: "半夜", pinyin: "bànyè", khmer: "ពាក់កណ្តាល<br>អាធ្រាត្រ"}
];


 const 对话 = [
      { hanzi: "你好！", pinyin: "nǐ hǎo!", khmer: "សួស្តី!" },
      { hanzi: "你好！", pinyin: "nǐ hǎo!", khmer: "សួស្តី!" },
      { hanzi: "你好吗？", pinyin: "nǐ hǎo ma?", khmer: "អ្នកសុខសប្បាយទេ?" },
      { hanzi: "我很好，你呢！", pinyin: "wǒ hěn hǎo, nǐ ne!", khmer: "ខ្ញុំសុខសប្បាយណាស់ អ្នកវិញ?" },
      { hanzi: "我很好。", pinyin: "wǒ hěn hǎo.", khmer: "ខ្ញុំសុខសប្បាយ។" },
      { hanzi: "好啊！谢谢你。", pinyin: "hǎo a! xièxie nǐ.", khmer: "ល្អហើយ! អរគុណអ្នក។" },
      { hanzi: "再见！", pinyin: "zàijiàn!", khmer: "លាហើយ!" }
    ];

const audioCache = {}; // memory cache

async function speakKhmer(text) {
  // If cached, use it
  if (audioCache[text]) {
    const audio = new Audio(audioCache[text]);
    audio.play();
    return;
  }

  // Call backend API to synthesize audio
  const response = await fetch("YOUR_BACKEND_API", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      input: { text },
      voice: { languageCode: "km-KH", name: "km-KH-Wavenet-A" },
      audioConfig: { audioEncoding: "MP3" }
    }),
  });

  const audioData = await response.json();
  const audioSrc = "data:audio/mp3;base64," + audioData.audioContent;

  // Cache the result in memory
  audioCache[text] = audioSrc;

  // Play the audio
  const audio = new Audio(audioSrc);
  audio.play();
}



function renderTable(data, title, containerId) {
  const container = document.getElementById(containerId);
  const section = document.createElement("section");
  section.innerHTML = `<h2>${title}</h2>`;

  const contentBox = document.createElement("div");
  contentBox.classList.add("content-box");

  data.forEach(item => {
    const div = document.createElement("div");
    div.classList.add("item");
    div.innerHTML = `
      <span>${item.hanzi}</span>
      ${item.pinyin ? `<span>${item.pinyin}</span>` : ""}
      <span>${item.khmer}</span>
    `;
    contentBox.appendChild(div);
  });

  section.appendChild(contentBox);
  container.appendChild(section);
}
// Render content on load
renderTable(initials, "声母（23个）- ព្យញ្ជនៈ", "initials");
renderTable(finals, "韵母（24个）- ស្រៈនិងស្រៈផ្សំ", "finals");
renderTable(zhengtiyin, "整体音节（16个）- ព្យញ្ជនៈពេញតួ", "zhengtiyin");
renderTable(words, "ពាក្យចិន និងអត្ថន័យខ្មែរ", "wordBox");
renderTable(numbers, "រៀនលេខចិន", "numbers");
renderTable(daysOfWeek, "រៀនចិន(ពាក្យថ្ងៃ)", "daysOfWeek");
renderTable(months, "រៀនចិន(ពាក្យខែ)", "months");
renderTable(chineseWords, "ពាក្យចិន", "chineseWords");
renderTable(pinyinTones, "ការបញ្ចេញសំឡេងនៃអក្សរចិន", "pinyinTones");
renderTable(chineseHours, "រៀនម៉ោងជាភាសាចិន", "chineseHours");
renderTable(timePeriods, "ពេលវេលា", "timePeriods");
renderTable(对话, "ពេលវេលា", "对话");
displayPronunciationExplanation();
